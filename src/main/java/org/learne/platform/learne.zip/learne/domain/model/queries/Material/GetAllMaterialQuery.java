package org.learne.platform.learne.domain.model.queries.Material;

public record GetAllMaterialQuery() {
}
