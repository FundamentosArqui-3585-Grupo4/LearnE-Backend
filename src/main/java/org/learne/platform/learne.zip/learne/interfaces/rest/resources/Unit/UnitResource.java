package org.learne.platform.learne.interfaces.rest.resources.Unit;

public record UnitResource(Long id, Long course_id, String title) {
}
