package org.learne.platform.learne.domain.model.queries.Unit;

public record GetAllUnitsQuery() {
}
