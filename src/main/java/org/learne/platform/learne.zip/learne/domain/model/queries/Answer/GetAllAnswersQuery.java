package org.learne.platform.learne.domain.model.queries.Answer;

public record GetAllAnswersQuery() {
}
