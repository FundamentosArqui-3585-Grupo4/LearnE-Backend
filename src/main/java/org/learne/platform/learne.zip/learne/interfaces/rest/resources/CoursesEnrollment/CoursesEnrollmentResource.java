package org.learne.platform.learne.interfaces.rest.resources.CoursesEnrollment;

public record CoursesEnrollmentResource(Long id, Long student_id, Long course_id) {
}
