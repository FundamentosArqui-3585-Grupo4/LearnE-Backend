package org.learne.platform.learne.interfaces.rest.resources.Exam;

public record CreateExamResource(Long unit_id, Long course_id, String title) {
}
