package org.learne.platform.learne.interfaces.rest.resources.TutorialsReservated;

public record CreateTutorialsReservatedResource(Long student_id, Long tutorial_id) {
}
