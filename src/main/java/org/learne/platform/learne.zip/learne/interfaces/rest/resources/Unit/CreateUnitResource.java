package org.learne.platform.learne.interfaces.rest.resources.Unit;

public record CreateUnitResource(Long course_id, String title) {
}
