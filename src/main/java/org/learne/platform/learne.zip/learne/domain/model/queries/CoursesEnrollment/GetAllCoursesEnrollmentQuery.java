package org.learne.platform.learne.domain.model.queries.CoursesEnrollment;

public record GetAllCoursesEnrollmentQuery() {
}
