package org.learne.platform.learne.domain.model.queries.TutorialsReservated;

public record GetAllTutorialsReservatedQuery() {
}
