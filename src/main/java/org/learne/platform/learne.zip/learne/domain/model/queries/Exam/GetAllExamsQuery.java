package org.learne.platform.learne.domain.model.queries.Exam;

public record GetAllExamsQuery() {
}
