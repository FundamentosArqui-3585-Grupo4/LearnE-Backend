package org.learne.platform.learne.interfaces.rest.resources.CoursesEnrollment;

public record CreateCoursesEnrollmentResource(Long student_id, Long course_id) {
}
