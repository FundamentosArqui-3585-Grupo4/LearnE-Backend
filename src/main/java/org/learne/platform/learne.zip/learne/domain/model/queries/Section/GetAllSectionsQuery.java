package org.learne.platform.learne.domain.model.queries.Section;

public record GetAllSectionsQuery() {
}
