package org.learne.platform.learne.interfaces.rest.resources.Question;

public record QuestionResource(Long id, Long exam_id, String question) {
}
