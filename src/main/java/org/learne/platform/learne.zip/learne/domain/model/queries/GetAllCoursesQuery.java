package org.learne.platform.learne.domain.model.queries;

/**
 * Query to get all courses
 */
public record GetAllCoursesQuery() {
}
