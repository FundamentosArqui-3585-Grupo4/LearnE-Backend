package org.learne.platform.learne.interfaces.rest.resources.Question;

public record CreateQuestionResource(Long exam_id, String question) {
}
