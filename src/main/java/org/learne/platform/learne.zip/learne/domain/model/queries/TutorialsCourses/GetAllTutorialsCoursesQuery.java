package org.learne.platform.learne.domain.model.queries.TutorialsCourses;

public record GetAllTutorialsCoursesQuery() {
}
