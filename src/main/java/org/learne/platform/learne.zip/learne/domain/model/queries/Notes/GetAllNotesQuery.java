package org.learne.platform.learne.domain.model.queries.Notes;

public record GetAllNotesQuery() {
}
