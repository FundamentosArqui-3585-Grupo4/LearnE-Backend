package org.learne.platform.learne.interfaces.rest.resources.Notes;

public record NoteResource(Long id,Long student_id, Long exam_id, Float note) {
}
