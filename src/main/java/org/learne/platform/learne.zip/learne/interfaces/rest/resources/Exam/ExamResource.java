package org.learne.platform.learne.interfaces.rest.resources.Exam;

public record ExamResource(Long id, Long unit_id, Long course_id, String title) {
}
