package org.learne.platform.learne.domain.model.queries.Question;

public record GetAllQuestionsQuery () {

}
