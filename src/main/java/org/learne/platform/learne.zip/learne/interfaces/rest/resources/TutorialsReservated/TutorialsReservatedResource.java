package org.learne.platform.learne.interfaces.rest.resources.TutorialsReservated;

public record TutorialsReservatedResource(Long id, Long student_id, Long tutorial_id) {
}
